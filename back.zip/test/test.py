with open(r'D:\谐波源python\matlab\upcc.txt','r') as f:
    p=f.read()
    print(p)



