import sys,os
from sys import path
BASE_DIR=os.path.dirname(os.path.abspath(__file__));
path.append(BASE_DIR)
print(BASE_DIR)